# Pratik Dusane — Portfolio

UX and product design portfolio. Static site, no build step. Live at https://dusanepratik.com

## Pages
| File | Page |
|---|---|
| `index.html` | Home |
| `nexus.html` | Case study 01 · IITG Nexus |
| `bharattrack.html` | Case study 02 · BharatTrack |
| `kafila.html` | Case study 03 · Kafila |
| `*-prototype.html` | Live prototypes |
| `kafila-walkthrough.html` | Kafila, step by step |

## Folders
- `media/` — videos, homepage images and the resume PDF
- `assets/`, `assets-2/` — case study images

## Upload with the GitHub website (max 100 files per upload)
Open this folder, then in the repo use **Add file → Upload files** three times:
1. Select all the loose files **and** the `media` folder → drag in → Commit.
2. Drag the `assets` folder → Commit.
3. Drag the `assets-2` folder → Commit.

Files must sit at the top of the repo (you should see `index.html` on the repo's main page, not inside another folder).

## GitHub Pages
Settings → Pages → Source: **Deploy from a branch** → `main` / `(root)`.
Custom domain: `dusanepratik.com` (set by the `CNAME` file). Tick **Enforce HTTPS** when it appears.

## Updating the resume
Replace `media/Pratik-Dusane-Resume.pdf` with a new PDF of the same name.
