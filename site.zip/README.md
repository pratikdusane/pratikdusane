# Pratik Dusane — Portfolio

UX and product design portfolio. Static site, no build step. Live at https://dusanepratik.com

The site is kept as one file, `site.zip`. The GitHub Actions workflow in `.github/workflows/deploy.yml` unzips it and publishes it to GitHub Pages on every push.

## Pages
| File | Page |
|---|---|
| `index.html` | Home (light and dark, follows the device setting; toggle in the header) |
| `nexus.html` | Case study 01 · IITG Nexus |
| `bharattrack.html` | Case study 02 · BharatTrack |
| `kafila.html` | Case study 03 · Kafila |
| `*-prototype.html` | Live prototypes |

## Folders inside site.zip
- `media/` — videos, homepage images and the resume PDF
- `assets/`, `assets-2/` — case study images

## Updating
Upload a new `site.zip` with the same name to the repo root. The site is live about a minute later (green tick in the Actions tab).
